/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package simplelogin;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Aditya Mhatre
 */
public class RegFXMLController implements Initializable {

    @FXML
    private AnchorPane RegPane;
    @FXML
    private JFXButton RegB;
    @FXML
    private Label LogT;
    @FXML
    private Label close;
    @FXML
    private JFXTextField RegUser;
    @FXML
    private JFXPasswordField RegPass;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void logAction(MouseEvent event) {
    }

    @FXML
    private void RegTAction(MouseEvent event) throws IOException {
        AnchorPane pane = FXMLLoader.load(getClass().getResource("LoginFXML.fxml"));
        RegPane.getChildren().setAll(pane);
    }

    @FXML
    private void closeAction(MouseEvent event) {
        Stage stage = (Stage) RegPane.getScene().getWindow();
        stage.close();
    }
    
}
