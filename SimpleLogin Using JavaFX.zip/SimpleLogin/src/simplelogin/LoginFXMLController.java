/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package simplelogin;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import java.sql.*;

/**
 *
 * @author Aditya Mhatre
 */
public class LoginFXMLController implements Initializable {
    
    @FXML
    private AnchorPane LoginPane;
    @FXML
    private Label close;
    @FXML
    private JFXButton LogB;
    @FXML
    private Label RegT;
    @FXML
    private JFXTextField LogUser;
    @FXML
    private JFXPasswordField LogPass;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void closeAction(MouseEvent event) {
        Stage stage = (Stage) LoginPane.getScene().getWindow();
        stage.close();
    }

    @FXML
    private void logAction(MouseEvent event)    {
        
    }

    @FXML
    private void RegTAction(MouseEvent event) throws IOException {
        AnchorPane pane = FXMLLoader.load(getClass().getResource("RegFXML.fxml"));
        LoginPane.getChildren().setAll(pane);
    }
    
}
